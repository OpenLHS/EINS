# eins2023


Material for the [2024 Interdisciplinary summer school on digital health (École d'été interdisciplinaire en numérique de la santé)](https://eins.griis.ca), Sherbrooke University.
